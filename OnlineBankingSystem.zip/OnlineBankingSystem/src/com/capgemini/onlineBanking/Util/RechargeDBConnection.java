package com.capgemini.onlineBanking.Util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.capgemini.onlineBanking.exception.onlineBankingException;

//import com.capgemini.bank.exception.DemandDraftException;

public class RechargeDBConnection {
	
	private static Properties properties= new Properties();
	private static Connection connection;

	public static Connection getConnection() throws onlineBankingException{
		//System.out.println("hello");
		
		try {
			InputStream inputStream =new FileInputStream("resources//db.properties");
			properties.load(inputStream);
			String url=properties.getProperty("jdbc.url");
			String user=properties.getProperty("jdbc.username");
			String password=properties.getProperty("jdbc.password");
			inputStream.close();
			//System.out.println(url);
			//System.out.println(user);
			//System.out.println(password);
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver()); 
			connection = DriverManager.getConnection(url, user, password);
			
		} catch (FileNotFoundException e2) {
			throw new onlineBankingException("Could not Find properties file to connect to database.");
		} catch (IOException e) {
			throw new onlineBankingException("Could not read the database details from properties file.");
		} catch (SQLException e) {
			throw new onlineBankingException("Database connection problem.");
		}
		
		return connection;
	
	}

} 
