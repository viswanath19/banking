package com.capgemini.onlineBanking.pi;

import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.onlineBanking.bean.UserAccountBean;
import com.capgemini.onlineBanking.exception.onlineBankingException;
import com.capgemini.onlineBanking.service.IUserAccount;
import com.capgemini.onlineBanking.service.UserAccount;

public class Client {

	public static Scanner scan = new Scanner(System.in);
	IUserAccount inf = new UserAccount();
	
	//Method used to Logged in
	public String Login(){
		
		String userName = null;
		String pwd = null;
		
		System.out.println("Enter User Name : ");
		userName = scan.next();
		
		System.out.println("Enter Password : ");
		pwd = scan.next();
		String result=inf.isValidUser(userName,pwd);
		
		return result; 
	}
	
	
	//Method that register users
	/*public UserAccountBean Register(){
		
		UserAccountBean user = null;
		
		String userName = null;
		String pwd = null;
		long mobile;
		long accountno;
		String email = null;
		
		System.out.println("Enter User Name: ");
		userName = scan.next();
		
		System.out.println("Email Id : ");
		email = scan.next();
		
		System.out.println("Mobile Number :");
		mobile = scan.nextLong();
		System.out.println("Account number");
		accountno=scan.nextLong();
		
		System.out.println("Enter New Password : ");
		pwd = scan.next();
	
		user = new UserAccountBean();
		
		user.setUserName(userName);
		user.setPassword(pwd);
		
		user.setUserName(userName);
		user.setPassword(pwd);
		user.setMobile(mobile);
		user.setEmail(email);
		
		return user;
	}*/
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException, onlineBankingException {
		
		Client c = new Client();
		UserAccountBean user =new UserAccountBean();
		
		int choice;
		
		do{
		
			System.out.println("1. Log In");
			System.out.println("2. Register Account");
			
			System.out.println("Enter your choice(1-2) : ");
			choice = scan.nextInt();
			
			switch(choice){
				case 1:
					//Login In
					String bool = c.Login();
					if(bool!="false"){
						System.out.println("Welcome Succuessfully Logged In....");
						System.out.println("Choose the option");
						System.out.println("1.View Mini Statement");
						System.out.println("2.View Detailed Statement");
						System.out.println("3.Update Mobile number");
						System.out.println("4.Request for cheque book");
						System.out.println("5.Track cheque book request");
						long account=Long.valueOf(bool);
						//System.out.println(account);
						UserAccountBean rb=new UserAccountBean();
						rb.setAccNumber(account);
						System.out.println("Enter your choice");
						int choices=scan.nextInt();
						IUserAccount iua=new UserAccount();
						switch(choices){
						case 1:String miniStatement=iua.getMiniStatement(account);
							   System.out.println("Account Number                 Transaction Date");
							   System.out.println("_________________________________________________");
							   System.out.println(miniStatement);
						}
					}
					else{
						choice = -1;
						System.out.println("Invalid UserName and Password.....");
					}
					break;
				case 2:
					boolean userdetails=true;//Register
					userdetails = c.Register();
					if(userdetails==false){
						System.out.println("Sucessfully Registered.....");
					}
					else{
						choice = -1;
						System.out.println("Invalid Registration Details...");
					}
					
					
					break;
					
				default : System.out.println("Incorrect Choice....");
			}
		}while(choice!=1 && choice!=2);
		

	}


	private boolean Register() throws ClassNotFoundException, SQLException, IOException, onlineBankingException {
		String userName = null;
		String pwd = null;
		long mobile;
		long accountno;
		String email = null;
		
		System.out.println("Enter User Name: ");
		userName = scan.next();
		
		System.out.println("Email Id : ");
		email = scan.next();
		
		System.out.println("Mobile Number :");
		mobile = scan.nextLong();
		System.out.println("Account number");
		accountno=scan.nextLong();
		
		System.out.println("Enter New Password : ");
		pwd = scan.next();
	
	
		return inf.getRegistered(userName, pwd, mobile, accountno, email);
	}

}
